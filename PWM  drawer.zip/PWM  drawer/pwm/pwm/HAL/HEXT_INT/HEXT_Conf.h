/*
 * ext_conf.h
 *
 *  Created on: Sep 22, 2023
 *      Author: hp
 */

#ifndef HAL_HEXT_INT_HEXT_CONF_H_
#define HAL_HEXT_INT_HEXT_CONF_H_




#define INT0_PIN    PD2
#define INT1_PIN    PD3
#define INT2_PIN    PB2


#endif /* MCAL_EXT_EXT_CONF_H_ */
